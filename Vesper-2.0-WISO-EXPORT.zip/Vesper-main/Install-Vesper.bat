@echo off
setlocal EnableExtensions
cd /d "%~dp0Vesper-main"
if not exist package.json (
  echo FEHLER: Vesper-main\package.json wurde nicht gefunden.
  pause
  exit /b 1
)

echo ============================================
echo VESPER - PC INSTALLATION
echo ============================================
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js wurde nicht gefunden.
  echo Installiere Node.js LTS ueber winget...
  winget install --id OpenJS.NodeJS.LTS -e --accept-source-agreements --accept-package-agreements
  if errorlevel 1 (
    echo Node.js konnte nicht automatisch installiert werden.
    pause
    exit /b 1
  )
  echo Bitte Install-Vesper.bat nach der Installation erneut starten.
  pause
  exit /b 0
)
node --version
call npm --version

echo.
echo Installiere/aktualisiere Vesper-Abhaengigkeiten...
if exist node_modules\.bin\vite.cmd goto CHECK
call npm ci --no-audit --no-fund
if errorlevel 1 (
  echo.
  echo FEHLER: npm ci ist fehlgeschlagen.
  pause
  exit /b 1
)

:CHECK
if not exist node_modules\vite\bin\vite.js (
  echo FEHLER: Vite fehlt trotz erfolgreicher npm-Installation.
  pause
  exit /b 1
)

echo.
echo Fuehre Datenbank-Migrationen beim ersten Start automatisch aus.
echo.
echo ============================================
echo Installation erfolgreich abgeschlossen.
echo ============================================
echo Jetzt START-VESPER.bat ausfuehren.
pause
