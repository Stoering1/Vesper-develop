# Vesper 2 – Implementierungsstand

Diese Version legt die technische Grundlage für den produktiven Ausbau von Vesper.

## Enthalten

- PostgreSQL/PGlite-Migrationsschema für Betrieb, Räume, Tische, Artikel, Personal, Checks, Positionen, Zahlungen, Belege, Tagesabschlüsse und Audit-Log.
- Buchhaltungs-Schema für SKR03/SKR04, Buchungssätze und Export-Protokolle.
- DATEV-Arbeits-CSV, EÜR-Zusammenfassung und DSFinV-K-Arbeitsdatei als Test-/Vorbereitungs-Exporte.
- Persistenz der Tischpläne in der Datenbank; vorhandene Demo-Tischpläne werden beim ersten Lauf in die DB übernommen.
- Tischplan-Editor: Tisch hinzufügen, per Touch/Finger verschieben, Nummer und Plätze ändern, rechteckig/rund, Breite verändern, drehen, kopieren und löschen.
- iPad/PWA-Metadaten bleiben aktiv; die bestehende PWA-Installation kann auf dem iPad zum Home-Bildschirm hinzugefügt werden.

## Wichtig vor echtem Kassenbetrieb

Die aktuelle TSE-Implementierung im Projekt bleibt eine Demo-/Mock-Schicht. Sie darf nicht als zertifizierte TSE verstanden werden. Vor dem produktiven Einsatz muss ein zertifizierter TSE-Anbieter über den vorhandenen Adapter angebunden werden.

Die DATEV-, EÜR- und DSFinV-K-Exporte sind bewusst als technische Arbeitsgrundlage implementiert und müssen vor produktivem Einsatz mit dem verwendeten DATEV-/WISO-Prozess und dem Steuerberater fachlich validiert werden.

## Nächster technischer Schritt

Als nächstes sollte die gesamte POS-Transaktionslogik vom Zustandsspeicher in die oben angelegte PostgreSQL-Struktur migriert werden. Danach werden Offline-Synchronisation, echte TSE-Anbindung und der endgültige DATEV-/WISO-Export darauf aufgesetzt.

## WISO EÜR Export

Die Buchhaltungsseite enthält einen experimentellen WISO-Steuer-EÜR-XML-Export. Die WISO-Importstrecke ist vendor-spezifisch; Buhl dokumentiert den Import über „Daten importieren > Bürosoftware > WISO Mein Büro“, veröffentlicht aber kein vollständiges öffentliches XML-Schema. Deshalb ist der Export als Test-/Validierungsfunktion gekennzeichnet und muss gegen die konkret installierte WISO-Steuer-Version geprüft werden.
