create table if not exists pos_business (
  id text primary key,
  name text not null,
  address text not null default '',
  tax_id text not null default '',
  receipt_footer text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists pos_rooms (
  id text primary key,
  business_id text not null references pos_business(id) on delete cascade,
  name text not null,
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists pos_tables (
  id text primary key,
  business_id text not null references pos_business(id) on delete cascade,
  room_id text not null references pos_rooms(id) on delete restrict,
  number text not null,
  seats integer not null check (seats > 0),
  x numeric(6,3) not null check (x >= 0 and x <= 100),
  y numeric(6,3) not null check (y >= 0 and y <= 100),
  w numeric(6,3) not null check (w > 0 and w <= 100),
  h numeric(6,3) not null check (h > 0 and h <= 100),
  rotation numeric(6,2) not null default 0,
  shape text not null check (shape in ('rect','round','oval')),
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (business_id, room_id, number)
);

create index if not exists pos_tables_room_idx on pos_tables(room_id, active);

create table if not exists pos_categories (
  id text primary key,
  business_id text not null references pos_business(id) on delete cascade,
  name text not null,
  sort_order integer not null default 0,
  active boolean not null default true
);

create table if not exists pos_products (
  id text primary key,
  business_id text not null references pos_business(id) on delete cascade,
  category_id text references pos_categories(id) on delete set null,
  sku text not null default '',
  name text not null,
  price_cents integer not null check (price_cents >= 0),
  happy_hour_price_cents integer check (happy_hour_price_cents is null or happy_hour_price_cents >= 0),
  tax_class text not null,
  station text not null,
  course text not null,
  stock integer,
  active boolean not null default true,
  modifiers jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists pos_staff (
  id text primary key,
  business_id text not null references pos_business(id) on delete cascade,
  name text not null,
  pin_hash text not null,
  role text not null,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists pos_checks (
  id text primary key,
  business_id text not null references pos_business(id) on delete cascade,
  table_id text references pos_tables(id) on delete set null,
  check_type text not null,
  guest_count integer not null check (guest_count > 0),
  staff_id text references pos_staff(id) on delete set null,
  status text not null,
  notes text not null default '',
  discount_cents integer not null default 0,
  discount_label text not null default '',
  tip_cents integer not null default 0,
  opened_at timestamptz not null,
  paid_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists pos_check_items (
  id text primary key,
  check_id text not null references pos_checks(id) on delete cascade,
  product_id text references pos_products(id) on delete set null,
  name_snapshot text not null,
  unit_price_cents integer not null,
  quantity integer not null check (quantity > 0),
  tax_rate numeric(5,2) not null,
  course text not null,
  station text not null,
  modifiers jsonb not null default '[]'::jsonb,
  note text not null default '',
  seat integer,
  sent boolean not null default false,
  voided boolean not null default false
);

create table if not exists pos_payments (
  id text primary key,
  check_id text not null references pos_checks(id) on delete restrict,
  method text not null,
  amount_cents integer not null check (amount_cents >= 0),
  received_cents integer not null default 0 check (received_cents >= 0),
  paid_at timestamptz not null,
  staff_id text references pos_staff(id) on delete set null,
  provider text,
  provider_transaction_id text,
  reader_name text
);

create table if not exists pos_receipts (
  id text primary key,
  business_id text not null references pos_business(id) on delete cascade,
  check_id text not null,
  receipt_number bigint not null,
  receipt_type text not null,
  printed_at timestamptz not null,
  tse_transaction_number bigint,
  tse_signature text,
  tse_serial text,
  tse_start timestamptz,
  tse_end timestamptz,
  snapshot jsonb not null,
  unique (business_id, receipt_number)
);

create table if not exists pos_day_closes (
  id text primary key,
  business_id text not null references pos_business(id) on delete cascade,
  closed_at timestamptz not null,
  staff_id text references pos_staff(id) on delete set null,
  expected_cash_cents integer not null,
  counted_cash_cents integer not null,
  sales_by_method jsonb not null,
  vat jsonb not null,
  receipt_count integer not null,
  covers integer not null,
  tse jsonb not null
);

create table if not exists pos_audit_log (
  id text primary key,
  business_id text not null references pos_business(id) on delete cascade,
  occurred_at timestamptz not null default now(),
  staff_id text references pos_staff(id) on delete set null,
  action text not null,
  entity_type text not null,
  entity_id text,
  payload jsonb not null default '{}'::jsonb
);

create index if not exists pos_audit_log_business_time_idx on pos_audit_log(business_id, occurred_at);
create index if not exists pos_checks_business_status_idx on pos_checks(business_id, status, opened_at);
create index if not exists pos_payments_check_idx on pos_payments(check_id, paid_at);
create index if not exists pos_receipts_business_time_idx on pos_receipts(business_id, printed_at);
