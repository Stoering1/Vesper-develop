create table if not exists accounting_accounts (
  id text primary key,
  business_id text not null references pos_business(id) on delete cascade,
  chart text not null check (chart in ('SKR03','SKR04')),
  account_no text not null,
  name text not null,
  tax_code text,
  active boolean not null default true,
  unique (business_id, chart, account_no)
);

create table if not exists accounting_entries (
  id text primary key,
  business_id text not null references pos_business(id) on delete cascade,
  entry_date date not null,
  document_no text not null,
  document_date date not null,
  description text not null,
  debit_account text not null,
  credit_account text not null,
  amount_cents integer not null check (amount_cents > 0),
  tax_rate numeric(5,2),
  source_type text not null,
  source_id text not null,
  created_at timestamptz not null default now(),
  unique (business_id, source_type, source_id, debit_account, credit_account)
);

create index if not exists accounting_entries_business_date_idx on accounting_entries(business_id, entry_date);

create table if not exists accounting_exports (
  id text primary key,
  business_id text not null references pos_business(id) on delete cascade,
  export_type text not null check (export_type in ('datev','dsfinvk','wiso_eur','go_bd_archive')),
  period_from date not null,
  period_to date not null,
  created_at timestamptz not null default now(),
  checksum text not null,
  metadata jsonb not null default '{}'::jsonb
);
