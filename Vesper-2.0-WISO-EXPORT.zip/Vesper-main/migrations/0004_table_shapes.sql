-- Extend the table editor with oval tables. Existing installations get the
-- constraint upgraded idempotently; table data is preserved.
alter table if exists pos_tables drop constraint if exists pos_tables_shape_check;
alter table if exists pos_tables
  add constraint pos_tables_shape_check check (shape in ('rect','round','oval'));
