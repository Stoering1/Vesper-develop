import { useEffect, useMemo, useRef, useState, type PointerEvent as ReactPointerEvent } from "react";
import { useNavigate } from "@tanstack/react-router";
import { ArrowRightLeft, Copy, Edit3, Merge, Minus, Plus, RotateCw, Trash2, Users, Save, Circle, Square, CircleDashed, Check } from "lucide-react";
import { cn } from "@/lib/utils";
import { formatDuration, formatEUR } from "@/lib/pos/money";
import {
  checkTotal,
  tableLabel,
  tableStatus,
  usePosStore,
} from "@/lib/pos/store";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import type { FloorTable } from "@/lib/pos/types";
import { deleteTablePersisted, listPersistedTables, saveTableLayouts, saveTableLayout } from "@/lib/pos/persistence.server";

export function TablePlan() {
  const rooms = usePosStore((s) => s.rooms);
  const tables = usePosStore((s) => s.tables);
  const checks = usePosStore((s) => s.checks);
  const reservations = usePosStore((s) => s.reservations);
  const openTable = usePosStore((s) => s.openTable);
  const moveCheck = usePosStore((s) => s.moveCheck);
  const mergeChecks = usePosStore((s) => s.mergeChecks);
  const upsertTable = usePosStore((s) => s.upsertTable);
  const removeTable = usePosStore((s) => s.removeTable);
  const replaceTables = usePosStore((s) => s.replaceTables);
  const getOpenCheckForTable = usePosStore((s) => s.getOpenCheckForTable);
  const navigate = useNavigate();
  const [roomId, setRoomId] = useState(rooms[0]?.id ?? "");
  const [guestFor, setGuestFor] = useState<FloorTable | null>(null);
  const [guests, setGuests] = useState(2);
  const [moveFrom, setMoveFrom] = useState<string | null>(null);
  const [editMode, setEditMode] = useState(false);
  const [selectedTableId, setSelectedTableId] = useState<string | null>(null);
  const [drag, setDrag] = useState<{ id: string; x: number; y: number; ox: number; oy: number } | null>(null);
  const [saveState, setSaveState] = useState<"idle" | "saving" | "saved" | "error">("idle");
  const didHydrateDb = useRef(false);

  useEffect(() => {
    if (didHydrateDb.current) return;
    didHydrateDb.current = true;
    void listPersistedTables().then((persisted) => {
      if (persisted.length > 0) replaceTables(persisted);
      else void saveTableLayouts(tables);
    }).catch(() => undefined);
  }, [replaceTables, tables]);

  const roomTables = useMemo(
    () => tables.filter((t) => t.roomId === roomId),
    [tables, roomId],
  );

  function enterTable(table: FloorTable) {
    const existing = getOpenCheckForTable(table.id);
    if (existing) {
      void navigate({ to: "/tisch/$tableId", params: { tableId: table.id } });
      return;
    }
    setGuests(table.seats);
    setGuestFor(table);
  }

  function confirmOpen() {
    if (!guestFor) return;
    openTable(guestFor.id, guests);
    const id = guestFor.id;
    setGuestFor(null);
    void navigate({ to: "/tisch/$tableId", params: { tableId: id } });
  }

  function onTableClick(table: FloorTable) {
    if (moveFrom) {
      const moved = moveCheck(moveFrom, table.id);
      if (moved) setMoveFrom(null);
      return;
    }
    enterTable(table);
  }

  function onTablePointerDown(e: ReactPointerEvent<HTMLButtonElement>, table: FloorTable) {
    if (!editMode) return;
    e.preventDefault();
    e.currentTarget.setPointerCapture(e.pointerId);
    const rect = e.currentTarget.parentElement?.getBoundingClientRect();
    if (!rect) return;
    setSelectedTableId(table.id);
    setDrag({ id: table.id, x: e.clientX, y: e.clientY, ox: table.x, oy: table.y });
  }

  async function persistTable(table: FloorTable) {
    try {
      await saveTableLayout({ data: table });
      setSaveState("saved");
    } catch {
      setSaveState("error");
    }
  }

  async function savePlan() {
    setSaveState("saving");
    // Zustand persists every state change locally; this explicit action mirrors
    // the complete latest snapshot to the server database as well.
    try {
      await saveTableLayouts(usePosStore.getState().tables);
      setSaveState("saved");
    } catch {
      // The plan is still safely stored locally. Mark that the database mirror
      // needs another save rather than pretending the local save failed.
      setSaveState("error");
    }
  }

  function onTablePointerMove(e: ReactPointerEvent<HTMLButtonElement>) {
    if (!drag) return;
    const table = tables.find((t) => t.id === drag.id);
    const rect = e.currentTarget.parentElement?.getBoundingClientRect();
    if (!table || !rect) return;
    const nx = Math.max(0, Math.min(100 - table.w, drag.ox + ((e.clientX - drag.x) / rect.width) * 100));
    const ny = Math.max(0, Math.min(100 - table.h, drag.oy + ((e.clientY - drag.y) / rect.height) * 100));
    upsertTable({ ...table, x: Number(nx.toFixed(2)), y: Number(ny.toFixed(2)) });
  }

  function onTablePointerUp() {
    if (drag) {
      // Read the latest Zustand state. The pointer-move updates above are
      // asynchronous, so the `tables` closure can still contain the previous
      // position when pointerup fires (especially on iPad).
      const latest = usePosStore.getState().tables.find((t) => t.id === drag.id);
      if (latest) void persistTable(latest);
    }
    setDrag(null);
  }

  function changeSelected(patch: Partial<FloorTable>) {
    if (!selectedTableId) return;
    const table = tables.find((t) => t.id === selectedTableId);
    if (table) {
      const next = { ...table, ...patch };
      upsertTable(next);
      void persistTable(next);
    }
  }

  function addTable() {
    const next = tables.filter((t) => t.roomId === roomId).length + 1;
    const id = `t_${Date.now().toString(36)}`;
    const table: FloorTable = { id, number: String(next), roomId, seats: 2, x: 10, y: 10, w: 14, h: 20, shape: "rect", rotation: 0 };
    upsertTable(table);
    void persistTable(table);
    setSelectedTableId(id);
  }

  function duplicateSelected() {
    const table = tables.find((t) => t.id === selectedTableId);
    if (!table) return;
    const copy: FloorTable = { ...table, id: `t_${Date.now().toString(36)}`, number: `${table.number}a`, x: Math.min(86, table.x + 4), y: Math.min(80, table.y + 4) };
    upsertTable(copy);
    void persistTable(copy);
    setSelectedTableId(copy.id);
  }


  return (
    <div className="flex h-full min-h-0 flex-col">
      <div className="flex flex-wrap items-center gap-2 border-b border-border px-4 py-3">
        {rooms.map((r) => (
          <Button
            key={r.id}
            size="sm"
            variant={r.id === roomId ? "default" : "outline"}
            onClick={() => setRoomId(r.id)}
          >
            {r.name}
          </Button>
        ))}
        <div className="ml-auto flex items-center gap-2">
          {editMode ? (
            <>
              <Button size="sm" variant="default" onClick={() => void savePlan()} disabled={saveState === "saving"}>
                <Save className="size-4" /> {saveState === "saving" ? "Speichert…" : "Plan speichern"}
              </Button>
              <Button size="sm" variant="outline" onClick={() => setEditMode(false)}>Fertig</Button>
              <Button size="sm" variant="outline" onClick={addTable}><Plus className="size-4" /> Tisch</Button>
            </>
          ) : (
            <Button size="sm" variant="outline" onClick={() => { setSaveState("idle"); setEditMode(true); }}>
              <Edit3 className="size-4" /> Tischplan bearbeiten
            </Button>
          )}
        </div>
        <div className="hidden items-center gap-4 text-xs text-muted sm:flex">
          <Legend swatch="border-border bg-surface-2" label="Frei" />
          <Legend swatch="border-sage/50 bg-sage/20" label="Besetzt" />
          <Legend swatch="border-amber/50 bg-amber/20" label="Rechnung" />
          <Legend swatch="border-info/50 bg-info/15" label="Reserviert" />
        </div>
        {editMode ? (
          <span className={cn("text-xs", saveState === "error" ? "text-danger" : "text-muted")}>
            {saveState === "saving" ? "Speichere…" : saveState === "saved" ? "Gespeichert" : saveState === "error" ? "Lokal gespeichert · Server erneut versuchen" : "Bearbeitungsmodus"}
          </span>
        ) : null}
      </div>

      <div className="relative min-h-[430px] flex-1 p-3 sm:p-4">
        <div className={cn("relative h-full min-h-[430px] overflow-hidden rounded-xl border border-border bg-surface", editMode && "touch-none select-none")}>
          <div className="pointer-events-none absolute inset-0 opacity-30 [background-image:linear-gradient(to_right,var(--color-border)_1px,transparent_1px),linear-gradient(to_bottom,var(--color-border)_1px,transparent_1px)] [background-size:5%_5%]" />
          <div className="pointer-events-none absolute inset-6 rounded-lg border border-dashed border-border/80" />
          {roomTables.map((table) => {
            const status = tableStatus(table.id, checks, reservations);
            const check = getOpenCheckForTable(table.id);
            return (
              <button
                key={table.id}
                type="button"
                onClick={() => { if (editMode) setSelectedTableId(table.id); else onTableClick(table); }}
                onPointerDown={(e) => onTablePointerDown(e, table)}
                onPointerMove={onTablePointerMove}
                onPointerUp={onTablePointerUp}
                onContextMenu={(e) => e.preventDefault()}
                className={cn(
                  "absolute flex touch-none flex-col items-center justify-center gap-0.5 border px-2 text-center transition-[transform,background-color] duration-150 hover:scale-[1.02] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/40",
                  table.shape === "round" || table.shape === "oval" ? "rounded-full" : "rounded-lg",
                  status === "free" && "border-border bg-surface-2 text-muted",
                  status === "occupied" && "border-sage/50 bg-sage/20 text-fg",
                  status === "billed" && "border-amber/50 bg-amber/20 text-fg",
                  status === "reserved" && "border-info/50 bg-info/15 text-fg",
                  moveFrom && "ring-1 ring-accent/30",
                  editMode && selectedTableId === table.id && "ring-2 ring-accent",
                )}
                style={{
                  left: `${table.x}%`,
                  top: `${table.y}%`,
                  width: `${table.w}%`,
                  height: `${table.h}%`,
                  transform: `rotate(${table.rotation ?? 0}deg)`,
                }}
              >
                <span className="text-lg font-semibold leading-none">{table.number}</span>
                {check ? (
                  <>
                    <span className="font-mono text-xs tabular-nums">{formatEUR(checkTotal(check))}</span>
                    <span className="text-[11px] text-muted">
                      {check.guestCount} · {formatDuration(check.openedAt)}
                    </span>
                  </>
                ) : (
                  <span className="text-[11px] text-subtle">{table.seats} Plätze</span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {editMode && selectedTableId ? (() => {
        const selected = tables.find((t) => t.id === selectedTableId);
        if (!selected) return null;
        return (
          <div className="sticky bottom-0 z-10 flex flex-wrap items-center gap-2 border-b border-border bg-surface-2 px-3 py-3 shadow-sm sm:px-4">
            <span className="mr-1 text-sm font-medium">Tisch {selected.number}</span>
            <Input className="w-20" value={selected.number} aria-label="Tischnummer" onChange={(e) => changeSelected({ number: e.target.value })} />
            <Input className="w-20" type="number" min={1} max={50} value={selected.seats} aria-label="Sitzplätze" onChange={(e) => changeSelected({ seats: Math.max(1, Number(e.target.value) || 1) })} />
            <label className="flex items-center gap-2 text-xs text-muted">
              B
              <input className="w-24 accent-[var(--color-accent)]" type="range" min={6} max={45} step={1} value={Math.round(selected.w)} aria-label="Breite" onChange={(e) => changeSelected({ w: Number(e.target.value) })} />
            </label>
            <label className="flex items-center gap-2 text-xs text-muted">
              H
              <input className="w-24 accent-[var(--color-accent)]" type="range" min={8} max={60} step={1} value={Math.round(selected.h)} aria-label="Höhe" onChange={(e) => changeSelected({ h: Number(e.target.value) })} />
            </label>
            <span className="text-xs text-muted">Breite</span>
            <Button size="icon" variant="outline" aria-label="Breiter" onClick={() => changeSelected({ w: Math.min(45, selected.w + 2) })}><Plus className="size-4" /></Button>
            <Button size="icon" variant="outline" aria-label="Schmaler" onClick={() => changeSelected({ w: Math.max(6, selected.w - 2) })}><Minus className="size-4" /></Button>
            <span className="text-xs text-muted">Höhe</span>
            <Button size="sm" variant="outline" onClick={() => changeSelected({ h: Math.min(60, selected.h + 2) })}>Höher</Button>
            <Button size="sm" variant="outline" onClick={() => changeSelected({ h: Math.max(8, selected.h - 2) })}>Niedriger</Button>
            <Button size="sm" variant={selected.shape === "round" ? "default" : "outline"} onClick={() => changeSelected({ shape: "round" })}><Circle className="size-4" /> Rund</Button>
            <Button size="sm" variant={selected.shape === "rect" ? "default" : "outline"} onClick={() => changeSelected({ shape: "rect" })}><Square className="size-4" /> Rechteck</Button>
            <Button size="sm" variant={selected.shape === "oval" ? "default" : "outline"} onClick={() => changeSelected({ shape: "oval" })}><CircleDashed className="size-4" /> Oval</Button>
            <Button size="sm" variant="outline" onClick={() => changeSelected({ rotation: ((selected.rotation ?? 0) + 15) % 360 })}><RotateCw className="size-4" /> 15°</Button>
            <Button size="sm" variant="outline" onClick={duplicateSelected}><Copy className="size-4" /> Kopieren</Button>
            <Button size="sm" variant="ghost" className="text-danger" onClick={() => { removeTable(selected.id); void deleteTablePersisted({ data: { id: selected.id } }); setSelectedTableId(null); }}><Trash2 className="size-4" /> Löschen</Button>
            <span className="text-xs text-subtle">Finger ziehen · Größe/Rotation hier ändern</span>
          </div>
        );
      })() : null}

      <div className="grid grid-cols-2 gap-2 p-4 sm:grid-cols-3 md:hidden">
        {roomTables.map((table) => {
          const status = tableStatus(table.id, checks, reservations);
          const check = getOpenCheckForTable(table.id);
          return (
            <button
              key={table.id}
              type="button"
              onClick={() => { if (editMode) setSelectedTableId(table.id); else onTableClick(table); }}
              className={cn(
                "flex min-h-24 flex-col items-start justify-between rounded-lg border p-3 text-left",
                status === "free" && "border-border bg-surface-2",
                status === "occupied" && "border-sage/50 bg-sage/20",
                status === "billed" && "border-amber/50 bg-amber/20",
                status === "reserved" && "border-info/50 bg-info/15",
              )}
            >
              <span className="text-lg font-semibold">Tisch {table.number}</span>
              {check ? (
                <span className="font-mono text-sm tabular-nums">{formatEUR(checkTotal(check))}</span>
              ) : (
                <span className="text-xs text-muted">{table.seats} Plätze</span>
              )}
            </button>
          );
        })}
      </div>

      <div className="border-t border-border px-4 py-2 text-xs text-subtle">
        Rechtsklick-Aktionen über das Tisch-Menü in der Liste. Zum Umbuchen: Tisch wählen, dann Ziel antippen.
        {moveFrom ? (
          <span className="ml-2 text-amber">Umbuchen aktiv — Ziel-Tisch wählen oder abbrechen.</span>
        ) : null}
      </div>

      <div className="hidden overflow-x-auto border-t border-border md:block">
        <div className="flex min-w-max gap-2 px-4 py-3">
          {roomTables.map((table) => {
            const check = getOpenCheckForTable(table.id);
            return (
              <DropdownMenu key={table.id}>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="sm" className="font-mono">
                    {table.number}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  <DropdownMenuLabel>Tisch {table.number}</DropdownMenuLabel>
                  <DropdownMenuItem onClick={() => enterTable(table)}>Öffnen</DropdownMenuItem>
                  {check ? (
                    <>
                      <DropdownMenuItem onClick={() => setMoveFrom(check.id)}>
                        <ArrowRightLeft className="size-4" /> Umbuchen
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      {checks
                        .filter(
                          (c) =>
                            c.id !== check.id &&
                            c.status !== "paid" &&
                            c.status !== "voided" &&
                            c.tableId,
                        )
                        .slice(0, 8)
                        .map((c) => (
                          <DropdownMenuItem
                            key={c.id}
                            onClick={() => mergeChecks(check.id, c.id)}
                          >
                            <Merge className="size-4" />
                            Zusammenlegen mit {tableLabel(tables, c.tableId, c.type)}
                          </DropdownMenuItem>
                        ))}
                    </>
                  ) : null}
                </DropdownMenuContent>
              </DropdownMenu>
            );
          })}
          {moveFrom ? (
            <Button size="sm" variant="outline" onClick={() => setMoveFrom(null)}>
              Abbrechen
            </Button>
          ) : null}
        </div>
      </div>

      <Dialog open={!!guestFor} onOpenChange={(o) => !o && setGuestFor(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Tisch {guestFor?.number} öffnen</DialogTitle>
            <DialogDescription>Wie viele Gäste sitzen am Tisch?</DialogDescription>
          </DialogHeader>
          <div className="flex items-end gap-3">
            <div className="flex-1">
              <Label htmlFor="guests">Gäste</Label>
              <Input
                id="guests"
                type="number"
                min={1}
                max={20}
                value={guests}
                onChange={(e) => setGuests(Number(e.target.value) || 1)}
              />
            </div>
            <Users className="mb-2 size-5 text-muted" />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setGuestFor(null)}>
              Abbrechen
            </Button>
            <Button onClick={confirmOpen}>Tisch öffnen</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function Legend({ swatch, label }: { swatch: string; label: string }) {
  return (
    <span className="flex items-center gap-1.5">
      <span className={cn("size-3 rounded-sm border", swatch)} />
      {label}
    </span>
  );
}
